<?php
$_LANG['onpay_use_new_card'] = "Brug nyt kort";
$_LANG['onpay_pay_now'] = "Betal nu";