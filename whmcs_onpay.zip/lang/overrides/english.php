<?php
$_LANG['onpay_use_new_card'] = "Use new card";
$_LANG['onpay_pay_now'] = "Pay now";